# iOS_ota

iOS_OTA做最简单的OTA集成Demo程序。
项目包含:(1)一代6202芯片20字节传输hex和res（2）二代6212芯片使用长包传输hex和Res（3）支持Xip