//
//  FileManager.m
//  PHY
//
//  Created by Han on 2018/11/5.
//  Copyright © 2018年 phy. All rights reserved.
//

#import "FileManager.h"
#import "DDFileReader.h"
#import "JCDataConvert.h"
#import "Partition.h"

@interface FileManager()

@end

@implementation FileManager

- (instancetype)firmWareFile:(NSString *)filePath{
    return [self firmWareFile:filePath length:20];
}

- (instancetype)firmWareFile:(NSString *)filePath length:(int)length{
    FileManager *file = [[FileManager alloc] init];
    file.list = [NSMutableArray arrayWithCapacity:0];
    file.list = [[self analyzeFile:filePath length:length] copy];
    self.list = [NSMutableArray arrayWithCapacity:0];
    self.list = file.list;
    if ([filePath hasSuffix:@"bin"]) {
        file.length = [self getBinFileLength:filePath];
    }else {
        file.length = [self getLength];
    }
    
    return file;
}

- (instancetype)firmWareFileCDBB:(NSString *)filePath  length:(int)length {
    FileManager *file = [[FileManager alloc] init];
    file.list = [NSMutableArray arrayWithCapacity:0];
    file.list = [[self analyzeCDBBFile:filePath length:length] mutableCopy];
    self.list = [[NSMutableArray arrayWithCapacity:0] mutableCopy];
    self.list = file.list;
    file.length = [self getBinFileLength:filePath];
    
    return file;
}

- (NSArray *)analyzeCDBBFile:(NSString *)path length:(int)length{
    DDFileReader * reader = [[DDFileReader alloc] initWithFilePath:path];
    NSMutableArray *list = [NSMutableArray arrayWithCapacity:0];
    NSData * readOneTime = nil;
    //读length长度的数据，只要不为0，就将读到的数据放到list。
    while ( (readOneTime = [reader readCDBBBinFileWithLength:length]) && readOneTime.length>0) {
        [list addObject:readOneTime];
    }
    return list;
}

- (void)fixCDBBData {
    for (int i=0; i<self.list.count; i++) {
        if (i%16 == 0) {
            
        }else if((i%16)%15 == 0){
            NSString *crcResult = [JCDataConvert ToHex:[self cal_CRC16:self.list from:i-15 to:i] withLength:4];
            NSString *frameNumber = [JCDataConvert ToHex:i/16 withLength:4];
            NSString *headCmd = [NSString stringWithFormat:@"FFFE%@%@",frameNumber,crcResult];
            NSData *headData = [JCDataConvert hexToBytes:headCmd];
            NSMutableData *mData = [[NSMutableData alloc] init];
            [mData appendData:headData];
            [mData appendData:self.list[i-15]];
            [self.list replaceObjectAtIndex:i-15 withObject:mData];
            NSData *endData = [JCDataConvert hexToBytes:@"FEFF"];
            NSMutableData *nData = [[NSMutableData alloc] init];
            [nData appendData:self.list[i]];
            [nData appendData:endData];
            [self.list replaceObjectAtIndex:i withObject:nData];
        }else if(i == self.list.count-1){
            NSString* crcResult = [JCDataConvert ToHex:[self cal_CRC16:self.list from:i-(i%16) to:i] withLength:4];
            NSString *frameNumber = [JCDataConvert ToHex:i/16 withLength:4];
            NSString *headCmd = [NSString stringWithFormat:@"FFFE%@%@",frameNumber,crcResult];
            NSData *headData = [JCDataConvert hexToBytes:headCmd];
            NSMutableData *mData = [[NSMutableData alloc] init];
            [mData appendData:headData];
            [mData appendData:self.list[i-(i%16)]];
            [self.list replaceObjectAtIndex:i-(i%16) withObject:mData];
            NSData *endData = [JCDataConvert hexToBytes:@"FEFF"];
            NSMutableData *nData = [[NSMutableData alloc] init];
            [nData appendData:self.list[i]];
            [nData appendData:endData];
            [self.list replaceObjectAtIndex:i withObject:nData];
            
        }
    }
}

//这个方法应该放到工具类
- (UInt16)cal_CRC16:(NSArray *)dataArray from:(int)start to:(int)end {
    NSMutableData *allData = [NSMutableData new];
    for (int i = start; i<=end; i++) {
        NSData *data = dataArray[i];
        [allData appendData:data];
    }
    UInt16 number = [JCDataConvert checkSum:0 byte:allData];
    NSLog(@"CRC===%d",number);
    return number;
}

- (NSArray *)analyzeFile:(NSString *)path{
    return [self analyzeFile:path length:20];
}

- (NSArray *)analyzeFile:(NSString *)path length:(int)length{
    if ([path hasSuffix:@"bin"]) {
        return [self readBinFile:path length:length];
    }
    DDFileReader * reader = [[DDFileReader alloc] initWithFilePath:path];
    int size = 0;
    NSString *result = @"";
    NSMutableArray *tempArray = [NSMutableArray new];
    int flag = 0;
    NSString *address = @"";
    NSMutableArray *list = [NSMutableArray arrayWithCapacity:0];
    NSString * readline = nil;
    
    while ((readline = [reader readLine])) {
        NSLog(@"readline:%@",readline);
        NSString *hexSize = [readline substringWithRange:NSMakeRange(1, 2)];
        size = [JCDataConvert hexNumberStringToNumber:hexSize];
        
        if ([[readline substringWithRange:NSMakeRange(7, 2)] isEqualToString:@"04"]) {
            if (tempArray.count>0) {
                if (result.length >0)[tempArray addObject:result];
                Partition *partition;
                if([path hasSuffix:@"hexe16"]){
                    partition = [Partition securityPartition:address data:tempArray packetLength:length];
                }else{
                    partition = [Partition partition:address data:tempArray packetLength:length];
                }
                [list addObject:partition];
                [tempArray removeAllObjects];
            }
            address = [readline substringWithRange:NSMakeRange(9, 4)];
            flag = 0;
            result = @"";
            continue;
        }
        
        if ([[readline substringWithRange:NSMakeRange(7, 2)] isEqualToString:@"05"] || [[readline substringWithRange:NSMakeRange(7, 2)] isEqualToString:@"01"]) {
            if (result.length >0)[tempArray addObject:result];
            
            Partition *partition;
            if([path hasSuffix:@"hexe16"]){
                partition = [Partition securityPartition:address data:tempArray packetLength:length];
            }else{
                partition = [Partition partition:address data:tempArray packetLength:length];
            }
            [list addObject:partition];
            [tempArray removeAllObjects];
            break;
        }
        
        if (flag == 0) {
            flag = 1;
            NSString *str = [readline substringWithRange:NSMakeRange(3, 4)];
            address = [NSString stringWithFormat:@"%@%@",address,str];
        }
        
        NSString *resultStr = [readline substringWithRange:NSMakeRange(9, size*2)];
        result = [NSString stringWithFormat:@"%@%@",result,resultStr];
        //        NSLog(@"长度：%d",(int)result.length);
        if (result.length >= length*2) {
            [tempArray addObject:[result substringToIndex:length*2]];
            result = [result substringFromIndex:length*2];
        }
    }
    return list;
}


- (NSArray *)readBinFile:(NSString *)path length:(int)length{
    DDFileReader * reader = [[DDFileReader alloc] initWithFilePath:path];
    NSMutableArray *list = [NSMutableArray arrayWithCapacity:0];
    NSData * readOneTime = nil;
    //读length长度的数据，只要不为0，就将读到的数据放到list。
    while ( (readOneTime = [reader readBinFileWithLength:length]) && readOneTime.length>0) {
        //        NSLog(@"readOneTime:%@",readOneTime);
        [list addObject:readOneTime];
    }
    return list;
}

- (long)getLength {
    long size = 0;
    for (Partition *partition in self.list) {
        //        size += partition.partitionArray.count;
        if([partition isKindOfClass:[Partition class]])
            size += partition.partitionLength;
    }
    return size;
}

- (long)getBinFileLength:(NSString *)path{
    DDFileReader * reader = [[DDFileReader alloc] initWithFilePath:path];
    return [reader getTotalFileLength];
}

@end
