//
//  BluetoothListCellTableViewCell.m
//  PHY
//
//  Created by Han on 2018/9/28.
//  Copyright © 2018年 phy. All rights reserved.
//

#import "BluetoothListCell.h"
@implementation BluetoothListCell
- (void)awakeFromNib {
    [super awakeFromNib];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
}

- (void)setBlutoothInfo:(JCBlutoothInfoModel *)blutoothInfo{
    _blutoothInfo = blutoothInfo;
    NSNumber *RSSI = blutoothInfo.RSSI;
    BOOL isName = ([blutoothInfo.peripheral.name isEqualToString:@""] || blutoothInfo.peripheral.name == nil);//0405091212a212620000
    self.bluetoothName.text = isName ? @"Unnamed": blutoothInfo.realName;
    self.bluetoothMacName.text = blutoothInfo.peripheral.identifier.UUIDString;
    if (blutoothInfo.adverMacAddr != nil && blutoothInfo.adverMacAddr.length > 17) {
        
//        0405091212a212620000
        
        NSString *value = [NSString stringWithFormat:@"%@",blutoothInfo.adverMacAddr];
        if ([UIDevice currentDevice].systemVersion.floatValue >= 13.0 && [value containsString:@"length"]&& [value containsString:@"bytes"]) {
            NSRange rangeTemp = [value rangeOfString:@"0x"];
            value = [value substringFromIndex:rangeTemp.location+rangeTemp.length];
            value = [value stringByReplacingOccurrencesOfString:@"{" withString:@""];
            value = [value stringByReplacingOccurrencesOfString:@"}" withString:@""];
        }
//        //将iOS13以下字符串改成一样的格式
//        value = [value stringByReplacingOccurrencesOfString:@"<" withString:@""];
//        value = [value stringByReplacingOccurrencesOfString:@">" withString:@""];
//        value = [value stringByReplacingOccurrencesOfString:@" " withString:@""];
        if (value.length < 16) {
            NSLog(@"长度不对:%@",value);
            return;
        }
        
        NSMutableString*macString = [[NSMutableString alloc]init];
        [macString appendString:[[value substringWithRange:NSMakeRange(14,2)]uppercaseString]];
        [macString appendString:@":"];
        [macString appendString:[[value substringWithRange:NSMakeRange(12,2)]uppercaseString]];
        [macString appendString:@":"];
        [macString appendString:[[value substringWithRange:NSMakeRange(10,2)]uppercaseString]];
        [macString appendString:@":"];
        [macString appendString:[[value substringWithRange:NSMakeRange(8,2)]uppercaseString]];
        [macString appendString:@":"];
        [macString appendString:[[value substringWithRange:NSMakeRange(6,2)]uppercaseString]];
        [macString appendString:@":"];
        [macString appendString:[[value substringWithRange:NSMakeRange(4,2)]uppercaseString]];
        NSLog(@"adverMacAddr:%@",blutoothInfo.adverMacAddr);
        NSLog(@"macString:%@",macString);
        self.bluetoothMacName.text = macString;
    }
    /*计算蓝牙距离*/
    int iRssi = abs([RSSI intValue]);
    self.signaiStrengthLabel.text = [NSString stringWithFormat:@"%@dBm",RSSI];
    //    float power = (iRssi-59)/(10*2.0);
    //    float distance = pow(10, power);
    //    self.distance.text = [NSString stringWithFormat:@"%.3f米",distance];
    if (iRssi < 40) {
        self.signalImageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"信号3"]];//信号4
    }
    else if(iRssi > 100){
        self.signalImageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"信号0"]];
    }
    else if(iRssi <= 100 || iRssi >= 40){
        self.signalImageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"信号%01d",4-((iRssi - 20)/20)]];//5-((iRssi - 25)/15)
    }
}
@end
