//
//  bluetoothListViewController.m
//  PHY
//
//  Created by Han on 2018/9/28.
//  Copyright © 2018年 phy. All rights reserved.
//

#import "BluetoothListViewController.h"
#import "BluetoothListCell.h"
#import "OTAUpgradeViewController.h"


@interface BluetoothListViewController ()<UITableViewDelegate, UITableViewDataSource, JCBluetoothManagerDelegate>

@property (nonatomic, weak) JCBluetoothManager       *bluetoothManager;

@property (nonatomic, strong) NSMutableArray         *allBlutoothModel;//搜索到的周边设备
@property (nonatomic, strong) NSMutableArray         *sortArray;//显示数据，排序后的周边设备

//记录是哪个设备，OTA模式升级时需要对比信息
@property (nonatomic,strong) NSString                *originalMacAddress;
@property (nonatomic,strong) NSString                *originalUUID;

@property (weak, nonatomic) IBOutlet UITableView     *tableView;
@property (weak, nonatomic) IBOutlet UIView          *leftListView;
@property (weak, nonatomic) IBOutlet UIButton        *SLBButton;

@property (weak, nonatomic) IBOutlet UIBarButtonItem *rightBarButton;

@end

@implementation BluetoothListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.tableView registerNib:[UINib nibWithNibName:@"BluetoothListCell" bundle:[NSBundle mainBundle]] forCellReuseIdentifier:@"BluetoothListCell"];
    
    //蓝牙初始化
    _bluetoothManager = [JCBluetoothManager shareCBCentralManager];
    _bluetoothManager.delegate = self;
    
    _sortArray = [NSMutableArray array];
    _allBlutoothModel = [NSMutableArray array];
    
    //接收MAC设备MAC地址信息,如果广播数据包含了MAC地址，这个通知可以不要
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(bluetoothGetMacAddress:) name:@"BluetoothGetMacAddress" object:nil];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    
    [self.sortArray removeAllObjects];
    [self.allBlutoothModel removeAllObjects];
    [self.tableView reloadData];
    
    _bluetoothManager.delegate = self;
    
    if (self.bluetoothManager.bluetoothState == BluetoothOpenStateIsOpen) {
        [self rightBtnAction];
    }
    
}

#pragma mark -- storyboard事件

- (IBAction)leftBarButtonAction:(id)sender {
    
    self.leftListView.hidden = !self.leftListView.hidden;
    [self.leftListView bringSubviewToFront:self.view];
    
}

//是否是SLB OTA的标志位
- (IBAction)changeSLBModelAction:(UIButton *)sender {
    
    [OTAManager shareOTAManager].isSLB ++;
    [OTAManager shareOTAManager].isSLB %= ModeCount;
    if ([OTAManager shareOTAManager].isSLB == SBHMode) {
        [_SLBButton setTitle:@"SBH模式" forState:UIControlStateNormal];
    }else if([OTAManager shareOTAManager].isSLB == SLBMode){
        [_SLBButton setTitle:@"SLB模式" forState:UIControlStateNormal];
    }else if([OTAManager shareOTAManager].isSLB == CDBBMode){
        [_SLBButton setTitle:@"CDBB模式" forState:UIControlStateNormal];
    }
    
}

//配置Security OTA下的密钥
- (IBAction)changeKeyAction:(id)sender {
    
    self.leftListView.hidden = YES;
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"输入要更新的密钥" message:nil preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
    
    [alert addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        UITextField *keyValue = alert.textFields.firstObject;
        if(keyValue.text.length != 32) {
            NSString *tip = [NSString stringWithFormat:@"数据长度有误"];
            [self hudSetting:tip];
        }else{
            [OTAManager shareOTAManager].AESKey = keyValue.text;
        }
        
    }]];
    [alert addTextFieldWithConfigurationHandler:^(UITextField*_Nonnull textField) {
        textField.placeholder = @"请输入16位密钥";
    }];
    
    [self presentViewController:alert animated:YES completion:nil];
    
}

//查看Security OTA下的密钥
- (IBAction)checkKeyAction:(id)sender {
    
    self.leftListView.hidden = YES;
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:nil message:[OTAManager shareOTAManager].AESKey.length >0 ? [OTAManager shareOTAManager].AESKey : @"未设置,为空" preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleCancel handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
    
}

- (IBAction)rightBarButtonAction:(UIBarButtonItem *)sender {
    [self rightBtnAction];
}

#pragma mark - 可复用的方法

//右上角按钮事件
- (void)rightBtnAction {
    
    if([self.rightBarButton.title isEqualToString:@"停止"]){
        [self stopScanAction];
    }else{
        [self startScanAction];
    }
    
}

- (void)startScanAction {
    
    if (_bluetoothManager.bluetoothState == BluetoothOpenStateIsOpen) {
        self.rightBarButton.title = @"停止";
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        [_bluetoothManager reScan];//开始扫描外设
    }
    if (_bluetoothManager.bluetoothState == BluetoothOpenStateIsClosed) {
        UIAlertController *alertC = [UIAlertController alertControllerWithTitle:@"提示" message:@"请开启蓝牙连接设备" preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *action = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:nil];
        [alertC addAction:action];
        [self presentViewController:alertC animated:YES completion:nil];
        [MBProgressHUD hideHUDForView:self.view animated:YES];
    }
    
}

- (void)stopScanAction {
    
    self.rightBarButton.title = @"搜索";
    [MBProgressHUD hideHUDForView:self.view animated:YES];
    [_bluetoothManager stopScan];
    
}

- (void)hudSetting:(NSString *)tip {
    
    dispatch_async(dispatch_get_main_queue(), ^{
        MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        hud.mode = MBProgressHUDModeText;
        hud.label.text = tip;
        hud.label.numberOfLines = 0;
        hud.removeFromSuperViewOnHide = YES;
        [hud hideAnimated:YES afterDelay:5];
    });
    
}

- (void)bluetoothGetMacAddress:(NSNotification*)noti {
    
    NSString *originalMacAddress = noti.userInfo[@"originalMacAddress"];
    NSString *originalUUID = noti.userInfo[@"originalUUID"];
    self.originalMacAddress = originalMacAddress;
    self.originalUUID = originalUUID;
    
}

#pragma mark -- tableView设置

//设置tableview行
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _sortArray.count;
}

//设置行高
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 50;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    BluetoothListCell *cell = [tableView dequeueReusableCellWithIdentifier:@"BluetoothListCell" forIndexPath:indexPath];
    cell.blutoothInfo = _sortArray[indexPath.row];
    return cell;
}

//点击事件
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    JCBlutoothInfoModel *model = _sortArray[indexPath.row];
    MLDLog(@"选择的正在连接的设备：%@,%@",model.peripheral.name,model.adverMacAddr);
    [_bluetoothManager connectToPeripheral:model.peripheral];
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
}

#pragma mark - 蓝牙相关代理方法
//蓝牙未开启状态提醒
- (void)bluetoothStateChange:(JCBluetoothManager *)manager state:(BluetoothOpenState)openState {
    
    if (BluetoothOpenStateIsClosed == openState) {//关闭状态
        [self stopScanAction];
        UIAlertController *alertC = [UIAlertController alertControllerWithTitle:@"提示" message:@"请开启蓝牙连接设备" preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *action = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:nil];
        [alertC addAction:action];
        [self presentViewController:alertC animated:YES completion:nil];
    } else {
        MLDLog(@"根据回调开启扫描");
        [self startScanAction];
    }
    
}

//发现设备
- (void)foundPeripheral:(JCBluetoothManager *)manager peripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary *)advertisementData RSSI:(NSNumber *)RSSI {
    
    if ([peripheral.name isEqualToString:@""] || peripheral.name == nil ) {
        //过滤掉没有蓝牙名的设备
        return;
    }
    
    JCBlutoothInfoModel *model = [[JCBlutoothInfoModel alloc] init];
    model.peripheral = peripheral;
    model.RSSI = RSSI;
    model.advertisementData = advertisementData;
    NSString *localName = [advertisementData objectForKey:@"kCBAdvDataLocalName"];
    if(localName.length >0 )model.realName = localName;
    else model.realName = peripheral.name;
    NSObject *value = [advertisementData objectForKey:@"kCBAdvDataManufacturerData"];
    model.adverMacAddr = [JCDataConvert convertOriginalToMacString:value];
    MLDLog(@"发现的设备广播中1：%@,%@,%@",peripheral.identifier.UUIDString,peripheral.name,model.adverMacAddr);
    
    // 遍历数组中的蓝牙模型，更新原有的数据（主要是更新信号强度）
    for (NSInteger i = 0; i < _allBlutoothModel.count; i++) {
        JCBlutoothInfoModel *primaryModel = _allBlutoothModel[i];
        CBPeripheral *per = primaryModel.peripheral;
        if ([peripheral.identifier.UUIDString isEqualToString:per.identifier.UUIDString]) {
            [_allBlutoothModel replaceObjectAtIndex:i withObject:model];//更新数组中的数据
        }
    }
    
    // 若未有包含过此设备，则将其添加进数组中
    if (![_allBlutoothModel containsObject:model]) {
        [_allBlutoothModel addObject:model];
    }
    
    //  数组数据源中的模型 按信号值排序
    _sortArray = [NSMutableArray arrayWithArray:[_allBlutoothModel sortedArrayUsingComparator:^NSComparisonResult(JCBlutoothInfoModel *p1, JCBlutoothInfoModel *p2){
        return [p2.RSSI compare:p1.RSSI];
    }]];
    
    [self.tableView reloadData];
    
}

//连接蓝牙成功调用
- (void)bluetoothManager:(JCBluetoothManager *)manager didSucceedConectPeripheral:(CBPeripheral *)peripheral {
    
    JCBlutoothInfoModel *currentPer = nil;
    for (NSInteger i = 0; i < _allBlutoothModel.count; i++) {
        JCBlutoothInfoModel *primaryModel = _allBlutoothModel[i];
        CBPeripheral *per = primaryModel.peripheral;
        if ([peripheral.identifier.UUIDString isEqualToString:per.identifier.UUIDString]) {
            MLDLog(@"第一步：连接成功的外设信息：%@",primaryModel.advertisementData);
            currentPer = primaryModel;
        }
    }
    
    
    [self stopScanAction];
    
    //提示框提示调用成功
    NSString *tip = [NSString stringWithFormat:@"蓝牙连接成功: %@,状态：%@",currentPer.realName,peripheral.state==2?@"connected":@""];
    UIAlertController *alertC = [UIAlertController alertControllerWithTitle:@"提示" message:tip preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
        
        OTAUpgradeViewController *vc = [[OTAUpgradeViewController alloc]init];
        vc.mscAddress = self.originalMacAddress;
        vc.originalUUID = self.originalUUID;
        [self.navigationController pushViewController:vc animated:YES];
        
    }];
    [alertC addAction:action];
    [self presentViewController:alertC animated:YES completion:nil];
    
}

- (void)bluetoothManager:(nullable JCBluetoothManager *)manager
 didDisconnectPeripheral:(nullable CBPeripheral *)peripheral
                   error:(nullable NSError *)error {
    NSLog(@"与外设连接断开");
}

@end
